package teatro;

public class Artista extends Pessoa
{
    public Artista() {
        //
    }
}
